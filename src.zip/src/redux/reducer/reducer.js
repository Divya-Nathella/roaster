

const initialState={
    data:null
  }
  

function Reducer (state=initialState, action){
    switch(action.type){
        case 'hi':{
            console.log(state)
     return{...state,data:eval(action.payload)}

        }
        default:{
            console.log(state)
            return state
        }
    }
    
   
     
   
             }
export default Reducer;