import React from 'react';

function Towernameremove()
{
    return(
        <div className="Dnaa">
        
         <div className="Dna">
         <label>TOWER NAME</label>
         <input className="Dnai"></input>
         </div>
         <div className="Dna">
             <button className="Dnab">PUBLISH</button>
             <button className="Dnab">CANCEL</button>
         </div>
     </div>
    )
};
export default Towernameremove;