import React from 'react';
import './style.css'
function Domainnameremove ()
{
    return(
        <div className="Dnaa">
        <div className="Dna">
         <label>DOMAIN NAME</label>
         <input className="Dnai"></input>
         </div>
        
         <div className="Dna">
             <button className="Dnab">PUBLISH</button>
             <button className="Dnab">CANCEL</button>
         </div>
     </div>
    )

};
export default Domainnameremove;