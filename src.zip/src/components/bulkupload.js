import React, { useState } from 'react';
import axios from "axios"; //package used to POST TO Database
import { ReactExcel, readFile, generateObjects } from '@ramonak/react-excel'; //primary package that contains functions to read and transform excel sheet to JSON data



const App = () => {
  const [initialData, setInitialData] = useState(undefined);  //react hooks to store data read from excel sheet
  const [currentSheet, setCurrentSheet] = useState({}); //react hook to store excel sheet 
  const [generatedObjects, setGeneratedObjects] = useState([]); //react hook to store the data transformed from excel sheet
  
  // Function to upload excel sheet
  const handleUpload = (event) => {
    const file = event.target.files[0];
    readFile(file)
      .then((readedData) => setInitialData(readedData))
      .catch((error) => console.error(error));
  };

  
  
  // Function to tranform excel sheet data into JSON data as well as posting the JSON data to DynamoDB on click
  const handleClick = () => {
    const result = generateObjects(currentSheet); //calling the 'generateObjects' function to transfrom the data within 'currentSheet'
                                                  //to see where the 'generateObjects' function is written as well as the code,
                                                  //check the 'index.js' file in the '@ramonak\react-excel\dist' node module
    console.log(result);
    console.log(typeof(result));
        
    const url = "https://thlc4hm1fg.execute-api.ap-south-1.amazonaws.com/tranaction11/api1"
    //const url = url to the API, can be changed depending on the APIL location.

    setGeneratedObjects(result);
    axios.post(url, result).then(response => {  // Posting the JSON string data into DynamoDB
                                                       // A proxy has been defined inside the 'setupProxy.js' file, so the full url is
                                                       // not needed. 
      console.log("Status: ", response.status);  // console log information to check the status of the POST action
      console.log("Data: ", response.data.body); // console log information displaying what we are sending to DynamoDB
    }).catch(error => {
      console.error('Something went wrong!', error); //console log error catch message if POST action has failed
    });
  };
  
  return ( //here onwards is what will be displayed on the actual browser, nothing seems to be broken. 
           //https://github.com/KaterinaLupacheva/react-excel/tree/2ece901709f5cbf57e5f1a112cfbeb5993ca823d (Original Code Repository)
    <div className='App'>
      <input
        type='file'
        accept='.xlsx'
        onChange={handleUpload}
        id='upload'
        style={{ display: 'none' }}
      />
      <label htmlFor='upload'>
        <button
          className='custom-button'
          onClick={() => document.getElementById('upload').click()}
        >
          Upload
        </button>
      </label>
      <ReactExcel                  //this section of code allows us to make changes on the excel table displayed on the screen 
        initialData={initialData}
        onSheetUpdate={(currentSheet) => setCurrentSheet(currentSheet)}
        activeSheetClassName='active-sheet'
        reactExcelClassName='react-excel'
      />
      {initialData && ( //this section of code creates a button containing the 'handleClick' function that is defined at the top of this file.
        <button className='custom-button' onClick={handleClick}>
          Transform
        </button>
      )}
      {generatedObjects.length > 0 && ( //this section of code just displays the stringfy-ied JSON data in a text area
        <textarea
          cols={70}
          rows={30}
          value={JSON.stringify(generatedObjects, null, 2)}
          readOnly
          className='text-area'
        />
      )}
    </div>
  );
};

export default App;
