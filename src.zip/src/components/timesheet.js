import React,{useState} from 'react';
import Updateroaster from './updateroaster'
import Bulkupload from './bulkupload'
function Timesheet()
{
    const [active,setActive]=useState("Domainname1")
    return(
        <div className="header2">
            <div className="header2button">
            
            <label>BULK UPLOAD</label>
            <input type="radio"  name="1" onClick={()=>{setActive("Bulkupload")}}></input>
            <label>UPDATE ROASTER</label>
            <input type="radio" name="1"  onClick={()=>{setActive("Updateroaster")}}></input>
           
            </div>
            <div className="header2button2">
            {active==="Bulkupload"&&<Bulkupload/>}
            {active==="Updateroaster"&&<Updateroaster/>}
            
            </div>


        </div>
    )

};
export default Timesheet;