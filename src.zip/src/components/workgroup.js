import React,{useState} from 'react';
import Domainname from './domainname';
import Towername from './towername';
import Groupname from './groupname';
import './style.css'

function Workgroup()
{
    const [active,setActive]=useState("Domainname1")
    return(
        <div className="header2">
            <div className="header2button">
            <nav>
            <label>DOMAIN NAME</label>
            <input type="radio"  name="1" onClick={()=>{setActive("Domainname")}}></input>
            <label>TOWER NAME</label>
            <input type="radio" name="1"  onClick={()=>{setActive("Towername")}}></input>
            <label>GROUP NAME</label>
            <input type="radio" name="1" onClick={()=>{setActive("Groupname")}}></input>
            </nav>
            </div>
            <div className="header2button2">
            {active==="Domainname"&&<Domainname/>}
            {active==="Towername"&&<Towername/>}
            {active==="Groupname"&&<Groupname/>}
            </div>


        </div>
    )

};
export default Workgroup;