import React,{useState,useEffect} from "react";


import '../components/style.css'
import {useDispatch,useSelector} from 'react-redux'
import axios from 'axios'
import Table from '../table'
import Reducer from '../redux/reducer/reducer'

function Schedule()
{
    
    
    
    const [startDate,setstartDate]=useState("")
    const [endDate,setendDate]=useState("")
    const dispatch=useDispatch()
    const data =useSelector(state=>state.data)
    
   
   
    
    return(<div>
            <button onClick={() => {axios.get("https://fgoluch1mk.execute-api.ap-south-1.amazonaws.com/tranaction1/tranasction1")
                       .then(response=>{
                        dispatch({type:'hi',payload:response.data.body} )
                        console.log(response.data.body)
                        })
                       }}>REQUEST </button>
                       <button onClick={()=>{console.log('1', (data))}}></button>
                <button onClick={()=>{axios.post("https://fgoluch1mk.execute-api.ap-south-1.amazonaws.com/tranaction1/tranasction1",data)
                          .then(response=>{console.log(response.data.body)})
                     
                     }}>UPDATE</button>


                     <div className="Dnab"><Table/></div>


                     <div>
                     <input type="date" value={startDate} onChange={(e)=>{setstartDate(e.target.value)}}></input>
                           <input type="date" value={endDate} onChange={(e)=>{setendDate(e.target.value)}}></input>
                           <button onClick={()=>{console.log('1', (data))}}></button>
                <button onClick={()=>{axios.post("https://thlc4hm1fg.execute-api.ap-south-1.amazonaws.com/tranaction11/transcatio11",JSON.stringify({"data1":startDate,"data2":endDate}))
                          .then(response=>{
                            dispatch({type:'hi',payload:response.data.body})
                            console.log(response.data.body)
                        })
                     
                     }}>UPDATE</button> 
                     </div>
                    
        </div>
    )
};
export default Schedule;