import React,{useState} from 'react';
import './style.css'

function Updateroaster(){

return(
    <div className="urh">
      
     <div className="ur">
         <div>
             <label for="Domainname">DOMAINNAME</label>
         </div>
         <div>
             <input id="Domainname"></input>
         </div>
     </div>
     <div className="ur">
         <div>
             <label for="Towername">TOWERNAME</label>
         </div>
         <div>
             <input id="Towername"></input>
         </div>
     </div>
     <div className="ur">
         <div>
             <label for="Groupname">GROUPNAME</label>
         </div>
         <div>
             <input id="Groupname"></input>
         </div>
     </div>
     <div className="ur">
         <div>
             <label for="Smename">SMENAME</label>
         </div>
         <div>
             <input id="Smename"></input>
         </div>
     </div>
     <div className="ur">
         <div>
             <label for="Phone">PHONE</label>
         </div>
         <div>
             <input id="Phone"></input>
         </div>
     </div>
     <div className="ur">
         <div>
             <label for="Email">Email</label>
         </div>
         <div>
             <input id="Email"></input>
         </div>
     </div>
     <div className="ur">
         <div>
             <label for="Date">DATE</label>
         </div>
         <div>
             <input type="date" id="Date"></input>
         </div>
     </div>
     <div className="ur">
         <div>
             <label for="Shiftstart">SHIFTSTART</label>
         </div>
         <div>
             <input type="time"id="Shiftstart"></input>
         </div>
     </div>
     <div className="ur">
         <div>
             <label for="Shiftend">SHIFTEND</label>
         </div>
         <div>
             <input type="time" id="Shiftend"></input>
         </div>
     </div>

    </div>

)

};

export default Updateroaster;