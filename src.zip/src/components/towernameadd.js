import React from 'react';
import './style.css'
function Towernameadd ()
{
    return(
        <div className="Dnaa">
           <div className="Dna">
            <label>DOMAIN NAME</label>
            <input className="Dnai"></input>
            </div>
            <div className="Dna">
            <label>TOWER NAME</label>
            <input className="Dnai"></input>
            </div>
            <div className="Dna">
            <label>GROUP NAME</label>
            <input className="Dnai"></input>
            </div>
            <div className="Dna">
                <button className="Dnab">PUBLISH</button>
                <button className="Dnab">CANCEL</button>
            </div>
        </div>
    )

};
export default Towernameadd;