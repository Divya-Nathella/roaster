import  React,{useState} from 'react'
import Groupnameadd from './groupnameadd';
import Groupnameremove from './towernameremove';

function Groupname()
{
   const [active,setActive]=useState("add")
    return (

        <div className="Dn">
            <div className="Dn2">
            <button className="Dnb" onClick={()=>{setActive("add")}}>ADD</button>
            <button className="Dnb" onClick={()=>{setActive("remove")}}>REMOVE</button>
            </div>
            <div className="Dnb2">
            {active==="add"&&<Groupnameadd/>}
            {active==="remove"&&<Groupnameremove/>}
             </div>
        </div>
        
    )

};

export default Groupname;