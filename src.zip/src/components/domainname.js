import React,{useState} from 'react';
import Domainnameadd from'./domainnameadd';
import Domainnameremove from './domainnameremove';
import './style.css'

function Domainname()
{
    const [active,SetActive]=useState("domainadd")
 return(
     <div className="Dn">
          <div className="Dn2">
         <button className="Dnb"onClick={()=>SetActive("domainadd")}>ADD</button> <button className="Dnb" onClick={()=>SetActive("domainremove")}>Remove</button>
            </div>
            <div className="Dnb2">

            {active==="domainadd" && <Domainnameadd/>}
           { active==="domainremove" && <Domainnameremove/>}
           </div>
         

     </div>
     
 )

};

export default Domainname;