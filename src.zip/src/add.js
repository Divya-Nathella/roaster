import React from 'react'
function Add()
{
return(
    <div>
         <input >start date</input>
         <input >end date</input>
    </div>
    
)
};
export default Add;