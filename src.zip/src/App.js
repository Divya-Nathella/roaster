import logo from './logo.svg';
import React,{useEffect,useState} from "react"
import './App.css';
import {createStore,applyMiddleware} from 'redux'
import Axios from 'axios'
import Reducer from './redux/reducer/reducer'
import { Provider } from 'react-redux'
import  thunk from 'redux-thunk'
import Add from './add'


import Workgroup from'./components/workgroup'
import Timesheet from './components/timesheet'
import Schedule from './components/schedule'
import './components/style.css'



const store=createStore(Reducer,applyMiddleware(thunk))   

function App() {
  const[data,setData]=useState([])
  const[active,setActive]=useState("Home")
  return(<div>
    <Provider store={store}>
    <div className="header1">
      <div className="headerbutton">
        <div className="headerbutton1">
      <nav>
    <button className="button1">
      HOME
    </button>
    <button className="button1" onClick={()=>setActive("Schedule")}>
      SCHEDULE
    </button>
    <button className="button1" onClick={()=>setActive("Timesheet")}>
      TIMESHEET
    </button>
    <button  className="button1" onClick={()=>setActive("Workgroup")}>
      WORKGROUP
    </button>
    </nav>
    </div>
    </div>
    
   
    <div className="header1l">
     {active==="Workgroup" && <Workgroup/>}
     {active==="Timesheet" && <Timesheet/>} 
     {active==="Schedule" && <Schedule/>} 
    </div>
    </div>
    </Provider></div>)
  }


export default App;
