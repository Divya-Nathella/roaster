import React from "react";
import {useDispatch,useSelector} from 'react-redux'

export  default function Table(){
    const data =useSelector(state=>state.data)
    console.log(data)
    function submit1()
    {
        console.log("nj")
    }
    if(data!==null&&data!==undefined)
    {
       const columns=data[0]&& Object.keys(data[0])
        //
        console.log("if",columns)
        return (
            <div className="header1l">
            <form >
            <table cell padding={0} cellSpacing={0}>
                <thead>
                    <tr>{data[0]&&columns.map((heading)=><th>{heading}</th>)}</tr>
                </thead>
                <tbody>
                    {
                        data.map(row=><tr>
                            {
                                columns.map(columns=> <td>{<input  placeholder={row[columns] } onChange={(e)=>row[columns]=(e.target.value)}></input>}</td>)
                            }
                        </tr>)
                    }
                </tbody>
                
            </table>
            </form>
            </div>
            
        )
    }
    return typeof data
   
    
}